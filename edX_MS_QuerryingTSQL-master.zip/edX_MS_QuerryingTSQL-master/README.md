# edX 
## Microsoft: DAT201x Querying with Transact-SQL

Contains 11 lab sections for the 'Microsoft: DAT201x Querying with Transact-SQL' course provided by edX and Microsoft. 

Details of the course can be found [here](https://www.edx.org/course/querying-transact-sql-microsoft-dat201x-0).

